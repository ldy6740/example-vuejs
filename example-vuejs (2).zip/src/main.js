// import './assets/main.css'
import './assets/reset.css'
// import axios from 'axios';

import { createApp } from 'vue'
import App from './App.vue'

createApp(App).mount('#app')
// App.config.globalProperties.axios = axios;
